package com.example.acountdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AcountdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
