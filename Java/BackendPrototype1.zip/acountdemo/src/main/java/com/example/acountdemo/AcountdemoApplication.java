package com.example.acountdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcountdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcountdemoApplication.class, args);
	}

}
